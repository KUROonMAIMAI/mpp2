import React, { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, Text } from 'react-native-elements';

import { Client } from 'paho-mqtt';

const DriveScreen = () => {
  
  const [waterPumpStatus, setWaterPumpStatus] = useState<string>('停止');
  const [foodDispenserStatus, setFoodDispenserStatus] = useState<string>('停止');

  useEffect(() => {
    // 創建 MQTT 客戶端
    const client = new Client(
      '7b67f158630548c4bc44852099288d08.s1.eu.hivemq.cloud', // HiveMQ 公共 MQTT 代理地址
      8884, // WebSocket 端口
      `mqtt_${Math.random().toString(16).substr(2, 8)}` // 客戶端 ID
    );

    client.onConnectionLost = (responseObject: any) => {
      if (responseObject.errorCode !== 0) {
        console.error('MQTT 連接丟失:', responseObject.errorMessage);
      }
    };

    client.connect({
      useSSL: true,
      userName: 'tim031893',
      password: 'Wayne0412907',
      onSuccess: () => {
        console.log('MQTT driver已連接');
        client.subscribe('sensor/waterLevel');
        client.subscribe('sensor/foodWeight');
        client.subscribe('sensor/petWeight');
      },
      onFailure: (error:any) => {
        console.error('MQTT 連接失敗:', error);
      },
    });

    return () => {
      if (client.isConnected()) {
        client.disconnect();
      }
    };
  }, []);

  const handleWaterPump = () => {
    setWaterPumpStatus((prevStatus) => (prevStatus === '運行中' ? '停止' : '運行中'));
  };

  const handleFoodDispenser = () => {
    setFoodDispenserStatus((prevStatus) => (prevStatus === '運行中' ? '停止' : '運行中'));
  };

  return (
    <View style={styles.container}>


      <Text style={styles.welcomeText}>這是驅動頁面</Text>


      <View style={styles.box}>
        <Text style={styles.normalText}>
          水泵狀態      <Text style={styles.statusText}>{waterPumpStatus}</Text>
        </Text>
        <Button 
          title={waterPumpStatus === '運行中' ? '停止水泵' : '啟動水泵'}
          buttonStyle={styles.button}
          titleStyle={styles.buttonText}
          onPress={handleWaterPump} />
      </View>


      <View style={styles.box}>
        <Text style={styles.normalText}>
          飼料分配狀態      <Text style={styles.statusText}>{foodDispenserStatus}</Text>
        </Text>
        <Button 
          title={foodDispenserStatus === '運行中' ? '停止飼料分配' : '啟動飼料分配'} 
          buttonStyle={styles.button}
          titleStyle={styles.buttonText}
          onPress={handleFoodDispenser} />
      </View>


    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fcfcfc',
  },
  welcomeText: {
    fontWeight :'bold',
    marginBottom: 40,
    marginTop: 40,
    color: '#00caca',
    fontSize:30,
  },
  statusText: {
    fontWeight :'bold',
    marginVertical: 10,
    fontSize: 16,
    color: '#333',
  },
  normalText:{
    marginVertical: 10,
    fontSize: 16,
    color: '#333',
  },
  box:{
    flex: 1,
    marginVertical: 10,
    marginHorizontal: 20,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 80,
    paddingVertical: 10,
    borderRadius: 12, // 圓角邊框
    borderWidth: 10, // 邊框寬度
    borderColor:'#ffffff',
    justifyContent: 'center', // 垂直置中
    //alignItems: 'center', // 水平置中
  },

  button: {
    backgroundColor: '#00e3e3',
    paddingHorizontal: 40,
    paddingVertical: 20,
    borderRadius: 20,
  },

  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },

});

export default DriveScreen;